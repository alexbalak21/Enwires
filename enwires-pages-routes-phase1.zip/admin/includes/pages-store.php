<?php
// Admin-side storage for pages and routes (the Pages and Routes screens).
//
// Writes content/pages.json and content/routes.json (each with a backup first) and,
// for a new page, its starter content; deleting a page also removes its content.
// Reading is done by includes/pages-core.php, which the public site shares.

require_once __DIR__ . '/blocks-store.php';
require_once __DIR__ . '/layout-store.php';

define('PS_MAX_BACKUPS', 30);

// --- writing JSON with a backup ---------------------------------------------------

function ps_backup($file, $prefix) {
    if (!is_file($file)) {
        return;
    }
    if (!is_dir(BACKUPS_DIR)) {
        @mkdir(BACKUPS_DIR, 0775, true);
    }
    @copy($file, BACKUPS_DIR . '/' . $prefix . '-' . date('Ymd-His') . '.json');
    $files = glob(BACKUPS_DIR . '/' . $prefix . '-*.json') ?: [];
    if (count($files) > PS_MAX_BACKUPS) {
        sort($files);
        foreach (array_slice($files, 0, count($files) - PS_MAX_BACKUPS) as $f) {
            @unlink($f);
        }
    }
}

function ps_write_json($file, array $data, $prefix) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return false;
    }
    ps_backup($file, $prefix);
    $ok = bs_write_locked($file, $json);
    enw_pages_flush();      // the next read in this request sees the new data
    return $ok;
}

/** Write the whole route table (lang => route => entry). */
function ps_save_routes(array $tables) {
    $out = [];
    foreach (enw_route_langs() as $l) {
        $out[$l] = [];
        $langTable = (isset($tables[$l]) && is_array($tables[$l])) ? $tables[$l] : [];
        foreach ($langTable as $path => $e) {
            $out[$l][(string) $path] = [
                'page'     => (string) $e['page'],
                'redirect' => !empty($e['redirect']),
                'auto'     => !empty($e['auto']),
            ];
        }
    }
    return ps_write_json(ENW_ROUTES_FILE, ['version' => 1, 'routes' => $out], 'routes');
}

/** Fingerprint of the route table: detects that someone else changed it meanwhile. */
function ps_routes_rev() {
    return sha1(json_encode(enw_routes_load()));
}

// --- ids and addresses from a title -------------------------------------------------

/** "Qui sommes-nous ?" -> "qui-sommes-nous". Empty if nothing usable remains (e.g. only Chinese characters). */
function ps_slugify($s) {
    $s = trim((string) $s);
    $s = strtr($s, [
        'À'=>'A','Á'=>'A','Â'=>'A','Ã'=>'A','Ä'=>'A','Å'=>'A','à'=>'a','á'=>'a','â'=>'a','ã'=>'a','ä'=>'a','å'=>'a',
        'Ç'=>'C','ç'=>'c','È'=>'E','É'=>'E','Ê'=>'E','Ë'=>'E','è'=>'e','é'=>'e','ê'=>'e','ë'=>'e',
        'Ì'=>'I','Í'=>'I','Î'=>'I','Ï'=>'I','ì'=>'i','í'=>'i','î'=>'i','ï'=>'i','Ñ'=>'N','ñ'=>'n',
        'Ò'=>'O','Ó'=>'O','Ô'=>'O','Õ'=>'O','Ö'=>'O','ò'=>'o','ó'=>'o','ô'=>'o','õ'=>'o','ö'=>'o',
        'Ù'=>'U','Ú'=>'U','Û'=>'U','Ü'=>'U','ù'=>'u','ú'=>'u','û'=>'u','ü'=>'u','Ý'=>'Y','ý'=>'y','ÿ'=>'y',
        'Œ'=>'OE','œ'=>'oe','Æ'=>'AE','æ'=>'ae','ß'=>'ss',
    ]);
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s);
    return trim((string) $s, '-');
}

/** A free page id like "about_us": letters / digits / underscore, never a reserved or existing id. */
function ps_unique_page_id($base, array $pages) {
    $id = str_replace('-', '_', (string) $base);
    if ($id === '' || !preg_match('/^[a-z]/', $id)) {
        $id = 'page_' . $id;
    }
    $id = rtrim(substr($id, 0, 26), '_');
    if (strlen($id) < 2) {
        $id = 'page_' . substr(bin2hex(random_bytes(2)), 0, 4);
    }
    $candidate = $id;
    $n = 2;
    while (isset($pages[$candidate]) || in_array($candidate, enw_reserved_page_ids(), true)) {
        $candidate = $id . '_' . $n++;
    }
    return $candidate;
}

// --- pages ----------------------------------------------------------------------------

/**
 * Create a page: its entry, its English address and a starter block (a title).
 * Returns [bool ok, string|null message, page id|null]. ok with a message = created, with a warning.
 */
function ps_create_page($title, $route, $status) {
    if (!enw_structure_exists()) {
        return [false, 'Convert the site to blocks first (Dashboard → Convert now), then add pages.', null];
    }
    $title = enw_pages_clean_title($title);
    if ($title === '') {
        return [false, 'Please give the page a title.', null];
    }
    $route = enw_route_normalize($route);
    if ($route === '') {
        $route = ps_slugify($title);
    }
    if ($route === '') {
        return [false, 'An address could not be made from the title (try letters and digits). Type one in "Address".', null];
    }
    if (!enw_route_valid($route)) {
        return [false, 'The address "' . $route . '" is not valid. Use letters, digits and hyphens, in up to three parts separated by "/". Names like admin, assets or fr are reserved.', null];
    }
    $routes = enw_routes_load();
    if (isset($routes['en'][$route])) {
        return [false, 'The address /' . $route . ' is already used by another page or redirect. Choose another.', null];
    }

    $pages = enw_pages_load();
    $id = ps_unique_page_id(ps_slugify($route) !== '' ? ps_slugify($route) : ps_slugify($title), $pages);
    $status = ($status === 'published') ? 'published' : 'draft';

    // 1. the page
    $raw = enw_pages_raw();
    if (!isset($raw['pages']) || !is_array($raw['pages'])) {
        $raw['pages'] = [];
    }
    $raw['version'] = 1;
    $raw['pages'][$id] = ['title' => $title, 'status' => $status, 'created' => time()];
    if (!ps_write_json(ENW_PAGES_FILE, $raw, 'pages')) {
        return [false, 'Could not write content/pages.json. Open System check to see what to fix.', null];
    }

    // 2. its English address
    $tables = enw_routes_load();
    $tables['en'][$route] = ['page' => $id, 'redirect' => false, 'auto' => false];
    if (!ps_save_routes($tables)) {
        return [true, 'The page was created, but content/routes.json could not be written, so it has no address yet. Open System check, then add the address in Routes.', $id];
    }

    // 3. starter content: one "Page intro" block carrying the title
    $block = ['id' => enw_new_id('b_'), 'type' => 'page-intro',
              'fields' => ['eyebrow' => '', 'heading' => $title, 'text' => '', 'wide_title' => false, 'tight' => false]];
    $res = bs_save_page($id, 'en', [$block], ['title' => $title, 'description' => '', 'keywords' => ''], bs_page_rev($id, 'en'));
    if (empty($res['ok'])) {
        return [true, 'The page and its address were created, but the starter content could not be saved (' . (isset($res['error']) ? $res['error'] : 'unknown error') . '). Open the page in the builder and save it.', $id];
    }
    return [true, null, $id];
}

/** Change a page's title and (unless it is a system page) its status. */
function ps_update_page($id, $title, $status) {
    $p = enw_page_get($id);
    if ($p === null) {
        return [false, 'Unknown page.'];
    }
    $title = enw_pages_clean_title($title);
    if ($title === '') {
        return [false, 'The title cannot be empty.'];
    }
    $raw = enw_pages_raw();
    if (!isset($raw['pages']) || !is_array($raw['pages'])) {
        $raw['pages'] = [];
    }
    $entry = (isset($raw['pages'][$id]) && is_array($raw['pages'][$id])) ? $raw['pages'][$id] : [];
    $entry['title'] = $title;
    if (!$p['system'] && !$p['hidden']) {
        $entry['status'] = ($status === 'published') ? 'published' : 'draft';
    }
    $raw['pages'][$id] = $entry;
    $raw['version'] = 1;
    if (!ps_write_json(ENW_PAGES_FILE, $raw, 'pages')) {
        return [false, 'Could not write content/pages.json. Open System check to see what to fix.'];
    }
    return [true, null];
}

/** Delete a page created in the admin, with its addresses, content and menu links. */
function ps_delete_page($id) {
    $p = enw_page_get($id);
    if ($p === null) {
        return [false, 'Unknown page.'];
    }
    if ($p['builtin']) {
        return [false, 'Built-in pages cannot be deleted (Product can be unpublished instead).'];
    }

    // The block ids of the page, to remove their texts.
    $structure = enw_structure_load();
    $blockIds = [];
    $oldBlocks = (isset($structure[$id]) && is_array($structure[$id])) ? $structure[$id] : [];
    foreach ($oldBlocks as $b) {
        if (is_array($b) && isset($b['id'])) $blockIds[] = $b['id'];
    }

    // 1. every address of the page
    $tables = enw_routes_load();
    foreach (enw_route_langs() as $l) {
        foreach ($tables[$l] as $path => $e) {
            if ($e['page'] === $id) unset($tables[$l][$path]);
        }
    }
    if (!ps_save_routes($tables)) {
        return [false, 'Could not write content/routes.json. Nothing was deleted.'];
    }

    // 2. the page itself
    $raw = enw_pages_raw();
    unset($raw['pages'][$id]);
    if (!ps_write_json(ENW_PAGES_FILE, $raw, 'pages')) {
        return [false, 'The addresses were removed, but content/pages.json could not be written. Try again.'];
    }

    // 3. its blocks and texts
    if (isset($structure[$id])) {
        unset($structure[$id]);
        bs_structure_save($structure);
    }
    foreach (BS_LANGS as $l) {
        $d = cs_load($l);
        $changed = false;
        foreach ($blockIds as $bid) {
            if (isset($d['blocks'][$bid])) { unset($d['blocks'][$bid]); $changed = true; }
        }
        if (isset($d['pages'][$id])) { unset($d['pages'][$id]); $changed = true; }
        if ($changed) cs_save($l, $d);
    }

    // 4. menu links to the page
    $site = enw_site_load();
    $siteChanged = false;
    foreach (['nav', 'footer_nav'] as $key) {
        if (!isset($site[$key]) || !is_array($site[$key])) continue;
        $keep = [];
        foreach ($site[$key] as $item) {
            if (is_array($item) && ($item['kind'] ?? 'page') === 'page' && ($item['page'] ?? '') === $id) { $siteChanged = true; continue; }
            $keep[] = $item;
        }
        $site[$key] = $keep;
    }
    if ($siteChanged) {
        ls_site_save($site);
    }
    return [true, null];
}

// --- routes ---------------------------------------------------------------------------------

/**
 * Turn the rows of the Routes form into a clean table for one language.
 * $rows: list of ['path', 'page', 'redirect', 'auto', 'delete']. Returns [table, errors].
 */
function ps_routes_from_rows(array $rows) {
    $pages = enw_pages_load();
    $table = [];
    $errors = [];
    $n = 0;
    foreach ($rows as $r) {
        $n++;
        if (!is_array($r) || !empty($r['delete'])) continue;
        $pathRaw = trim((string) ($r['path'] ?? ''));
        $page = (string) ($r['page'] ?? '');
        if ($pathRaw === '' && $page === '') continue;                 // an empty row

        if ($page === '') {
            $errors[] = 'Row ' . $n . ': choose the page this address shows.';
            continue;
        }
        if (!isset($pages[$page]) || $pages[$page]['hidden']) {
            $errors[] = 'Row ' . $n . ': that page does not exist.';
            continue;
        }
        $path = enw_route_normalize($pathRaw);
        if (!enw_route_valid($path)) {
            $errors[] = 'Row ' . $n . ': "' . $pathRaw . '" is not a valid address. Use letters, digits and hyphens, in up to three parts separated by "/". Names like admin, assets or fr are reserved.';
            continue;
        }
        if ($path === '' && $page !== 'home') {
            $errors[] = 'Row ' . $n . ': the empty address (the home page) can only show the Home page.';
            continue;
        }
        if (isset($table[$path])) {
            $errors[] = 'Row ' . $n . ': the address "/' . $path . '" is used twice.';
            continue;
        }
        $table[$path] = [
            'page'     => $page,
            'redirect' => ($path !== '' && !empty($r['redirect'])),
            'auto'     => !empty($r['auto']),
        ];
    }
    return [$table, $errors];
}

/** Does this page have a real (non-redirect) address in the table or in the fallback table? */
function ps_page_has_real_route($page, array $table, array $fallback) {
    foreach ([$table, $fallback] as $t) {
        foreach ($t as $e) {
            if ($e['page'] === $page && !$e['redirect']) return true;
        }
    }
    return false;
}

/**
 * Save one language's routes.
 *  - an address that disappeared (changed or removed) gets an automatic 301 to the page's
 *    real address, so old links and search rankings keep working;
 *  - a redirect must lead somewhere: its page needs a real address.
 * Returns ['ok' => bool, 'error' => string, 'new_redirects' => [path, ...]].
 */
function ps_save_language_routes($lang, array $rows, $baseRev) {
    if (!in_array($lang, enw_route_langs(), true)) {
        return ['ok' => false, 'error' => 'Unknown language.'];
    }
    if (!hash_equals(ps_routes_rev(), (string) $baseRev)) {
        return ['ok' => false, 'error' => 'Someone else changed the routes while this page was open. Reload the page to see their changes (saving now would overwrite them).'];
    }

    $tables = enw_routes_load();
    list($new, $errors) = ps_routes_from_rows($rows);
    if ($errors) {
        return ['ok' => false, 'error' => implode(' ', $errors)];
    }
    if ($lang === 'en') {
        $new = ['' => ['page' => 'home', 'redirect' => false, 'auto' => false]] + $new;   // "/" is always the home page
    }

    $fallback = ($lang === 'en') ? $new : $tables['en'];

    // A redirect needs a real address to go to.
    foreach ($new as $path => $e) {
        if ($e['redirect'] && !ps_page_has_real_route($e['page'], $new, $fallback)) {
            $p = enw_page_get($e['page']);
            return ['ok' => false, 'error' => '"/' . $path . '" redirects to "' . ($p ? $p['title'] : $e['page']) . '", which has no real address' . ($lang === 'en' ? '' : ' (in this language or in English)') . '. Give that page an address first (untick "Redirect" on one row).'];
        }
    }

    // Old addresses of pages that still exist keep working.
    $created = [];
    foreach ($tables[$lang] as $path => $e) {
        $path = (string) $path;
        if ($e['redirect'] || $path === '' || isset($new[$path])) continue;
        if (ps_page_has_real_route($e['page'], $new, $fallback)) {
            $new[$path] = ['page' => $e['page'], 'redirect' => true, 'auto' => true];
            $created[] = '/' . $path;
        }
    }

    $tables[$lang] = $new;
    if (!ps_save_routes($tables)) {
        return ['ok' => false, 'error' => 'Could not write content/routes.json. Open System check to see what to fix.'];
    }
    return ['ok' => true, 'error' => '', 'new_redirects' => $created];
}
