<?php
// Pages: every page of the site. Create a page, rename it, publish or hide it (draft),
// delete it. A page's CONTENT is edited in the block builder; which URL shows it is set
// in Routes.
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
require_once __DIR__ . '/includes/pages-store.php';

function pg_h($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$languages = ['en' => 'EN', 'fr' => 'FR', 'zh' => '中文', 'ja' => '日本語'];
$notice = null;                       // [level, text]
$form = ['title' => '', 'route' => '', 'status' => 'draft'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');

    if (!admin_verify_csrf()) {
        $notice = ['bad', 'Your session expired — please try again.'];

    } elseif ($action === 'create') {
        $form = [
            'title'  => (string) ($_POST['title'] ?? ''),
            'route'  => (string) ($_POST['route'] ?? ''),
            'status' => (string) ($_POST['status'] ?? 'draft'),
        ];
        list($ok, $msg, $newId) = ps_create_page($form['title'], $form['route'], $form['status']);
        if ($ok && $msg === null) {
            header('Location: builder.php?page=' . urlencode($newId) . '&lang=en');   // straight to building it
            exit;
        }
        $notice = [$ok ? 'warn' : 'bad', $msg];
        if ($ok) {
            $form = ['title' => '', 'route' => '', 'status' => 'draft'];
        }

    } elseif ($action === 'save') {
        list($ok, $msg) = ps_update_page((string) ($_POST['id'] ?? ''), (string) ($_POST['title'] ?? ''), (string) ($_POST['status'] ?? 'draft'));
        $notice = $ok ? ['ok', 'Saved.'] : ['bad', $msg];

    } elseif ($action === 'delete') {
        list($ok, $msg) = ps_delete_page((string) ($_POST['id'] ?? ''));
        $notice = $ok ? ['ok', 'The page was deleted, with its addresses, content and menu links.'] : ['bad', $msg];
    }
}

enw_pages_flush();
$pages = enw_pages_load();
$routes = enw_routes_load();

$pageTitle = 'Pages';
require __DIR__ . '/includes/layout-header.php';
?>
<style>
  .pg-table { width: 100%; border-collapse: collapse; font-size: .92rem; }
  .pg-table th { text-align: left; padding: 8px 8px; border-bottom: 2px solid var(--line); white-space: nowrap; }
  .pg-table td { padding: 10px 8px; border-bottom: 1px solid var(--line); vertical-align: top; }
  .pg-table input[type="text"], .pg-table select, .pg-create input[type="text"], .pg-create select { width: 100%; box-sizing: border-box; padding: 8px 10px; border: 1px solid var(--line); border-radius: 4px; font: inherit; background: #fff; }
  .pg-create { display: grid; grid-template-columns: 2fr 2fr 1fr auto; gap: 12px; align-items: end; }
  .pg-tag { display: inline-block; font-size: .72rem; padding: 1px 8px; border-radius: 10px; background: #eee; color: var(--ink-dim); margin-left: 6px; }
  .pg-tag.draft { background: #fff3cd; color: #7a5b00; }
  .pg-note { font-size: .8rem; color: var(--ink-dim); }
  .pg-links a { margin-right: 8px; white-space: nowrap; }
  .pg-warn { background: #fff8e1; border-left: 4px solid #e0a100; padding: 10px 14px; border-radius: 4px; margin-bottom: 14px; }
  @media (max-width: 800px) { .pg-create { grid-template-columns: 1fr; } }
</style>

<a href="index.php" class="back-link">&larr; Back to dashboard</a>
<h1>Pages</h1>
<p class="subtitle">Every page of the site. Add a page, publish it, give it an address in <a href="routes.php">Routes</a>, and build it in the block builder.</p>

<?php if ($notice): ?>
  <?php if ($notice[0] === 'warn'): ?>
    <div class="pg-warn"><?php echo pg_h($notice[1]); ?></div>
  <?php else: ?>
    <div class="alert <?php echo $notice[0] === 'ok' ? 'alert-success' : 'alert-error'; ?>"><?php echo pg_h($notice[1]); ?></div>
  <?php endif; ?>
<?php endif; ?>

<div class="panel">
  <h2 style="margin-top:0;">Add a page</h2>
  <form method="post" class="pg-create">
    <?php echo admin_csrf_field(); ?>
    <input type="hidden" name="action" value="create">
    <div>
      <label class="field-label" for="new-title">Title</label>
      <input type="text" id="new-title" name="title" required maxlength="120" value="<?php echo pg_h($form['title']); ?>" placeholder="About us">
    </div>
    <div>
      <label class="field-label" for="new-route">Address (English)</label>
      <input type="text" id="new-route" name="route" maxlength="120" value="<?php echo pg_h($form['route']); ?>" placeholder="made from the title, e.g. about-us">
    </div>
    <div>
      <label class="field-label" for="new-status">Status</label>
      <select id="new-status" name="status">
        <option value="draft" <?php echo $form['status'] !== 'published' ? 'selected' : ''; ?>>Draft (hidden)</option>
        <option value="published" <?php echo $form['status'] === 'published' ? 'selected' : ''; ?>>Published</option>
      </select>
    </div>
    <div><button type="submit" class="btn-primary">Create and build</button></div>
  </form>
  <p class="pg-note" style="margin-bottom:0;">The page starts with a title block. A draft cannot be seen by visitors; you can still preview it in the builder. The address can be changed later in Routes, and other languages can have their own.</p>
</div>

<div class="panel">
  <h2 style="margin-top:0;">All pages</h2>
  <table class="pg-table">
    <thead>
      <tr><th style="width:26%;">Title</th><th>Address</th><th style="width:150px;">Status</th><th>Edit content</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($pages as $id => $p): ?>
      <?php
        $enRoute = $p['hidden'] ? null : enw_page_route($id, 'en');
        $own = [];                                   // languages with their own address
        foreach (['fr', 'zh', 'ja'] as $l) {
            foreach ($routes[$l] as $path => $e) {
                if ($e['page'] === $id && !$e['redirect']) { $own[$l] = (string) $path; break; }
            }
        }
      ?>
      <tr>
        <td>
          <input type="text" form="pf-<?php echo pg_h($id); ?>" name="title" value="<?php echo pg_h($p['title']); ?>" maxlength="120" aria-label="Title">
          <?php if ($p['system']): ?><span class="pg-tag">system</span><?php elseif ($p['builtin']): ?><span class="pg-tag">built-in</span><?php endif; ?>
        </td>
        <td>
          <?php if ($p['hidden']): ?>
            <span class="pg-note">shown for any unknown address</span>
          <?php elseif ($enRoute === null): ?>
            <span class="pg-note" style="color:#b33;">no address yet — <a href="routes.php?lang=en">add one</a></span>
          <?php else: ?>
            <a href="<?php echo pg_h('/' . enw_route_encode($enRoute)); ?>" target="_blank" rel="noopener"><code>/<?php echo pg_h($enRoute); ?></code></a>
            <?php foreach ($own as $l => $path): ?>
              <br><span class="pg-note"><?php echo pg_h(strtoupper($l)); ?>: <code>/<?php echo pg_h($l . '/' . $path); ?></code></span>
            <?php endforeach; ?>
          <?php endif; ?>
        </td>
        <td>
          <?php if ($p['system'] || $p['hidden']): ?>
            <span class="pg-note">always published</span>
          <?php else: ?>
            <select form="pf-<?php echo pg_h($id); ?>" name="status" aria-label="Status">
              <option value="published" <?php echo $p['status'] === 'published' ? 'selected' : ''; ?>>Published</option>
              <option value="draft" <?php echo $p['status'] === 'draft' ? 'selected' : ''; ?>>Draft (hidden)</option>
            </select>
          <?php endif; ?>
        </td>
        <td class="pg-links">
          <?php foreach ($languages as $code => $label): ?>
            <a href="builder.php?page=<?php echo urlencode($id); ?>&amp;lang=<?php echo urlencode($code); ?>"><?php echo pg_h($label); ?></a>
          <?php endforeach; ?>
        </td>
        <td style="white-space:nowrap;">
          <button type="submit" form="pf-<?php echo pg_h($id); ?>" name="action" value="save" class="btn-secondary">Save</button>
          <?php if (!$p['builtin']): ?>
            <button type="submit" form="pf-<?php echo pg_h($id); ?>" name="action" value="delete" class="btn-secondary"
                    onclick="return confirm('Delete this page, all its content in the four languages, its addresses and its menu links? This cannot be undone (a backup of the files is kept).');">Delete</button>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>

  <?php foreach ($pages as $id => $p): ?>
    <form id="pf-<?php echo pg_h($id); ?>" method="post">
      <?php echo admin_csrf_field(); ?>
      <input type="hidden" name="id" value="<?php echo pg_h($id); ?>">
    </form>
  <?php endforeach; ?>

  <p class="pg-note" style="margin-bottom:0;">
    System pages (Home, Contact, 404) cannot be deleted or hidden; Product can be set to Draft. Where each page lives, and in which language, is set in <a href="routes.php">Routes</a>.
  </p>
</div>

<?php require __DIR__ . '/includes/layout-footer.php'; ?>
