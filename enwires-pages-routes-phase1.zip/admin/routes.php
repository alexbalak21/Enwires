<?php
// Routes: which address shows which page. Two fields per row: the address ("Server route")
// and the page it points to. One table per language: a page without its own address in a
// language keeps its English address under /fr/, /zh/, /ja/.
//
// Changing or removing an address leaves an automatic redirect (301) from the old one,
// so no link and no search ranking breaks.
require_once __DIR__ . '/includes/auth.php';
admin_require_login();
require_once __DIR__ . '/includes/pages-store.php';

function rt_h($s) {
    return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$languages = ['en' => 'English', 'fr' => 'Français', 'zh' => '中文', 'ja' => '日本語'];
$lang = isset($_GET['lang']) ? (string) $_GET['lang'] : 'en';
if (!isset($languages[$lang])) {
    $lang = 'en';
}
$prefix = ($lang === 'en') ? '/' : '/' . $lang . '/';

$notice = null;
$postedRows = null;       // rows to show again when the form has errors

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!admin_verify_csrf()) {
        $notice = ['bad', 'Your session expired — please try again.'];
    } else {
        $rows = (isset($_POST['rows']) && is_array($_POST['rows'])) ? array_values($_POST['rows']) : [];
        $res = ps_save_language_routes($lang, $rows, (string) ($_POST['rev'] ?? ''));
        if ($res['ok']) {
            $msg = 'Saved.';
            if (!empty($res['new_redirects'])) {
                $msg .= ' Old addresses now redirect (301) to the new one: ' . implode(', ', $res['new_redirects']) . '.';
            }
            $notice = ['ok', $msg];
        } else {
            $notice = ['bad', $res['error']];
            $postedRows = $rows;
        }
    }
}

enw_pages_flush();
$pages = enw_pages_load();
$tables = enw_routes_load();
$table = $tables[$lang];

// Rows to show: the saved table, or what was typed when saving failed.
$rows = [];
if ($postedRows !== null) {
    foreach ($postedRows as $r) {
        if (!is_array($r) || !empty($r['delete'])) continue;
        $rows[] = ['path' => (string) ($r['path'] ?? ''), 'page' => (string) ($r['page'] ?? ''),
                   'redirect' => !empty($r['redirect']), 'auto' => !empty($r['auto'])];
    }
} else {
    foreach ($table as $path => $e) {
        $rows[] = ['path' => (string) $path, 'page' => $e['page'], 'redirect' => $e['redirect'], 'auto' => $e['auto']];
    }
}
$blankRows = 3;

// Pages that use their English address in this language (informational).
$inherited = [];
if ($lang !== 'en') {
    foreach ($pages as $id => $p) {
        if ($p['hidden']) continue;
        $has = false;
        foreach ($table as $e) {
            if ($e['page'] === $id && !$e['redirect']) { $has = true; break; }
        }
        $enRoute = enw_page_route($id, 'en');
        if (!$has && $enRoute !== null) $inherited[] = [$p['title'], $enRoute];
    }
}

function rt_options(array $pages, $selected) {
    $html = '<option value="">— choose a page —</option>';
    foreach ($pages as $id => $p) {
        if ($p['hidden']) continue;
        $html .= '<option value="' . rt_h($id) . '"' . ($id === $selected ? ' selected' : '') . '>'
               . rt_h($p['title'] . ($p['status'] === 'draft' ? ' (draft)' : '')) . '</option>';
    }
    return $html;
}

function rt_row_html($i, array $r, array $pages, $prefix, $lang, $isHome) {
    $html  = '<tr>';
    $html .= '<td style="white-space:nowrap;"><span class="rt-prefix">' . rt_h($prefix) . '</span>'
           . '<input type="text" name="rows[' . $i . '][path]" value="' . rt_h($r['path']) . '" maxlength="120" '
           . ($isHome ? 'readonly title="The home page is always at /"' : 'placeholder="about-us"') . ' aria-label="Address"></td>';
    $html .= '<td><select name="rows[' . $i . '][page]"' . ($isHome ? ' style="pointer-events:none;background:#f3f3f6;"' : '') . ' aria-label="Page">' . rt_options($pages, $r['page']) . '</select></td>';
    $html .= '<td style="text-align:center;">' . ($isHome ? '' : '<input type="checkbox" name="rows[' . $i . '][redirect]" value="1"' . ($r['redirect'] ? ' checked' : '') . ' aria-label="Redirect">') . '</td>';
    $html .= '<td style="text-align:center;">' . ($isHome ? '' : '<input type="checkbox" name="rows[' . $i . '][delete]" value="1" aria-label="Delete this row">') . '</td>';
    $html .= '<td class="rt-note">';
    if ($r['auto']) $html .= '<span class="rt-tag">automatic</span> ';
    if ($r['redirect']) $html .= '<span class="rt-tag">redirect</span> ';
    $p = isset($pages[$r['page']]) ? $pages[$r['page']] : null;
    if ((!$r['redirect'] && $p !== null && $p['status'] === 'published' && $r['path'] !== '') || $isHome) {
        $url = '/' . ($lang === 'en' ? '' : $lang . '/') . enw_route_encode($r['path']);
        $html .= '<a href="' . rt_h($url) . '" target="_blank" rel="noopener">open ↗</a>';
    }
    $html .= '<input type="hidden" name="rows[' . $i . '][auto]" value="' . ($r['auto'] ? '1' : '') . '"></td>';
    $html .= '</tr>';
    return $html;
}

$pageTitle = 'Routes';
require __DIR__ . '/includes/layout-header.php';
?>
<style>
  .rt-langs { display: flex; gap: 6px; margin-bottom: 14px; flex-wrap: wrap; }
  .rt-langs a { text-decoration: none; padding: 6px 14px; border: 1px solid var(--line); border-radius: 4px; color: var(--ink); background: #fff; }
  .rt-langs a.is-active { background: var(--ink); color: #fff; border-color: var(--ink); }
  .rt-table { width: 100%; border-collapse: collapse; font-size: .92rem; }
  .rt-table th { text-align: left; padding: 8px; border-bottom: 2px solid var(--line); white-space: nowrap; }
  .rt-table td { padding: 7px 8px; border-bottom: 1px solid var(--line); vertical-align: middle; }
  .rt-table input[type="text"], .rt-table select { width: 100%; box-sizing: border-box; padding: 8px 10px; border: 1px solid var(--line); border-radius: 4px; font: inherit; background: #fff; }
  .rt-table input[type="text"] { display: inline-block; width: calc(100% - 46px); min-width: 120px; }
  .rt-prefix { display: inline-block; width: 42px; color: var(--ink-dim); font-family: ui-monospace, Menlo, Consolas, monospace; }
  .rt-note { font-size: .8rem; color: var(--ink-dim); }
  .rt-tag { display: inline-block; font-size: .7rem; padding: 1px 7px; border-radius: 10px; background: #eee; margin-right: 4px; }
  .rt-help { font-size: .85rem; color: var(--ink-dim); }
</style>

<a href="index.php" class="back-link">&larr; Back to dashboard</a>
<h1>Routes</h1>
<p class="subtitle">Which address shows which page. <a href="pages.php">Manage the pages themselves</a>.</p>

<?php if ($notice): ?>
  <div class="alert <?php echo $notice[0] === 'ok' ? 'alert-success' : 'alert-error'; ?>"><?php echo rt_h($notice[1]); ?></div>
<?php endif; ?>

<nav class="rt-langs" aria-label="Language">
  <?php foreach ($languages as $code => $name): ?>
    <a href="routes.php?lang=<?php echo urlencode($code); ?>" class="<?php echo $code === $lang ? 'is-active' : ''; ?>"><?php echo rt_h($name); ?></a>
  <?php endforeach; ?>
</nav>

<div class="panel">
  <form method="post" action="routes.php?lang=<?php echo urlencode($lang); ?>">
    <?php echo admin_csrf_field(); ?>
    <input type="hidden" name="rev" value="<?php echo rt_h(ps_routes_rev()); ?>">

    <table class="rt-table">
      <thead>
        <tr><th>Server route</th><th style="width:34%;">Page it points to</th><th style="width:90px; text-align:center;" title="Answer with a 301 redirect to the page's real address instead of showing the page there">Redirect</th><th style="width:70px; text-align:center;">Delete</th><th></th></tr>
      </thead>
      <tbody id="rt-body">
        <?php
          $i = 0;
          foreach ($rows as $r) {
              $isHome = ($lang === 'en' && $r['path'] === '' && $r['page'] === 'home');   // locked in English only
              echo rt_row_html($i++, $r, $pages, $prefix, $lang, $isHome);
          }
          for ($k = 0; $k < $blankRows; $k++) {
              echo rt_row_html($i++, ['path' => '', 'page' => '', 'redirect' => false, 'auto' => false], $pages, $prefix, $lang, false);
          }
        ?>
      </tbody>
    </table>

    <p style="margin:14px 0 0;">
      <button type="button" class="btn-secondary" id="rt-add">+ Add a row</button>
      <button type="submit" class="btn-primary">Save routes</button>
    </p>
  </form>

  <template id="rt-tpl"><?php echo rt_row_html('__I__', ['path' => '', 'page' => '', 'redirect' => false, 'auto' => false], $pages, $prefix, $lang, false); ?></template>
</div>

<div class="panel rt-help">
  <p style="margin-top:0;"><strong>How it works</strong></p>
  <ul style="margin:0 0 0 18px;">
    <li><strong>Server route</strong> is the part after <code><?php echo rt_h($prefix); ?></code>: lowercase letters, digits and hyphens, up to three parts separated by “/” (for example <code>about</code> or <code>services/web-design</code>). Names used by the site itself (<code>admin</code>, <code>assets</code>, <code>fr</code> …) are reserved.</li>
    <li><strong>Several routes can point to the same page.</strong> Tick <strong>Redirect</strong> on an alias to send visitors (and search engines, with a 301) to the page's real address instead of showing the page twice.</li>
    <li><strong>When you change or remove an address</strong>, the old one keeps working: it redirects automatically to the new one.</li>
    <li><strong>The empty route</strong> (the home page) cannot be changed or removed. A page that is a draft, or has no address, shows the 404 page.</li>
    <li>To delete a row, tick <strong>Delete</strong> and save.</li>
  </ul>
  <?php if ($lang !== 'en'): ?>
    <p style="margin-bottom:0;">
      <strong>Language fallback:</strong> a page that has no row here keeps its <em>English</em> address under <code><?php echo rt_h($prefix); ?></code>.
      Add a row only to give a page a different address in this language (for example <code><?php echo rt_h($prefix); ?>a-propos</code>).
      <?php if ($inherited): ?>
        <br>Using their English address now:
        <?php echo implode(', ', array_map(function ($x) { return rt_h($x[0]) . ' (<code>/' . rt_h($x[1]) . '</code>)'; }, $inherited)); ?>.
      <?php endif; ?>
    </p>
  <?php endif; ?>
</div>

<script>
  (function () {
    var body = document.getElementById('rt-body');
    var tpl = document.getElementById('rt-tpl');
    var next = body.querySelectorAll('tr').length;
    document.getElementById('rt-add').addEventListener('click', function () {
      var wrap = document.createElement('tbody');
      wrap.innerHTML = tpl.innerHTML.replace(/__I__/g, String(next++));
      while (wrap.firstChild) body.appendChild(wrap.firstChild);
      var inputs = body.querySelectorAll('tr:last-child input[type="text"]');
      if (inputs.length) inputs[0].focus();
    });
  })();
</script>

<?php require __DIR__ . '/includes/layout-footer.php'; ?>
