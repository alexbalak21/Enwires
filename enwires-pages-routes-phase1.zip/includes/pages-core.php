<?php
// Pages and routes — the two small tables behind the "Pages" and "Routes" screens of the admin.
//
//   content/pages.json    which pages exist: title and draft / published
//   content/routes.json   which URL shows which page, per language
//
// The four built-in pages (home, product, contact, 404) always exist, so the site
// works before anything is saved. Pages created in the admin all use the generic
// template page.php; their content is blocks, like every other page.
//
// This file is standalone (no dependency on the current language): router.php, the
// public site, the admin and the sitemap all use it.

if (!defined('ENW_CONTENT_DIR')) {
    define('ENW_CONTENT_DIR', dirname(__DIR__) . '/content');
}
define('ENW_PAGES_FILE', ENW_CONTENT_DIR . '/pages.json');
define('ENW_ROUTES_FILE', ENW_CONTENT_DIR . '/routes.json');

function enw_route_langs() {
    return ['en', 'fr', 'zh', 'ja'];
}

/** First URL segments that belong to the site itself and can never be a page route. */
function enw_route_reserved_segments() {
    return ['admin', 'assets', 'includes', 'content', 'data', 'text', 'fr', 'zh', 'ja',
            'set-lang', 'router', 'sitemap', 'robots', 'favicon', 'static'];
}

/** Page ids that cannot be used for new pages. */
function enw_reserved_page_ids() {
    return ['home', 'product', 'contact', 'notfound', 'blocks', 'layout', 'nav', 'site', 'pages', 'structure', 'default'];
}

// --- Pages ----------------------------------------------------------------------

function enw_pages_builtin() {
    return [
        'home'     => ['title' => 'Home',                 'template' => 'index.php',   'status' => 'published', 'system' => true,  'builtin' => true, 'hidden' => false],
        'product'  => ['title' => 'Product (SiBoost)',    'template' => 'product.php', 'status' => 'published', 'system' => false, 'builtin' => true, 'hidden' => false],
        'contact'  => ['title' => 'Contact',              'template' => 'contact.php', 'status' => 'published', 'system' => true,  'builtin' => true, 'hidden' => false],
        'notfound' => ['title' => '404 page (not found)', 'template' => '404.php',     'status' => 'published', 'system' => true,  'builtin' => true, 'hidden' => true],
    ];
}

function enw_page_id_valid($id) {
    return is_string($id) && preg_match('/^[a-z][a-z0-9_]{1,29}$/', $id) === 1;
}

function enw_pages_clean_title($v) {
    if (!is_string($v)) return '';
    $v = trim(preg_replace('/[\r\n\t]+/', ' ', strip_tags($v)));
    return function_exists('mb_substr') ? mb_substr($v, 0, 120, 'UTF-8') : substr($v, 0, 120);
}

/** Forget what was read from disk (after a save, inside the same request). */
function enw_pages_flush() {
    $GLOBALS['__enw_pages_cache'] = null;
    $GLOBALS['__enw_routes_cache'] = null;
    $GLOBALS['__enw_link_opts'] = null;
}

function enw_pages_raw() {
    if (!is_file(ENW_PAGES_FILE)) return [];
    $d = json_decode((string) file_get_contents(ENW_PAGES_FILE), true);
    return is_array($d) ? $d : [];
}

/**
 * All pages: id => [title, template, status, system, builtin, hidden].
 * Built-in pages first, then the pages created in the admin, in creation order.
 */
function enw_pages_load() {
    if (isset($GLOBALS['__enw_pages_cache'])) {
        return $GLOBALS['__enw_pages_cache'];
    }
    $pages = enw_pages_builtin();
    $raw = enw_pages_raw();
    $saved = (isset($raw['pages']) && is_array($raw['pages'])) ? $raw['pages'] : [];

    foreach ($saved as $id => $p) {
        $id = (string) $id;
        if (!is_array($p)) continue;
        $title = enw_pages_clean_title($p['title'] ?? '');
        $status = (($p['status'] ?? '') === 'draft') ? 'draft' : 'published';

        if (isset($pages[$id])) {                       // built-in: only title / status can be changed
            if ($title !== '') $pages[$id]['title'] = $title;
            if (!$pages[$id]['system'] && !$pages[$id]['hidden']) $pages[$id]['status'] = $status;
            continue;
        }
        if (!enw_page_id_valid($id) || in_array($id, enw_reserved_page_ids(), true)) continue;
        $pages[$id] = [
            'title' => $title !== '' ? $title : $id, 'template' => 'page.php', 'status' => $status,
            'system' => false, 'builtin' => false, 'hidden' => false, 'created' => (int) ($p['created'] ?? 0),
        ];
    }
    $GLOBALS['__enw_pages_cache'] = $pages;
    return $pages;
}

function enw_page_get($key) {
    $pages = enw_pages_load();
    return isset($pages[$key]) ? $pages[$key] : null;
}

function enw_page_is_published($key) {
    $p = enw_page_get($key);
    return $p !== null && $p['status'] === 'published';
}

// --- Routes ---------------------------------------------------------------------

/** Lower case, no spaces, no leading / trailing slash. */
function enw_route_normalize($s) {
    $s = trim((string) $s);
    $t = preg_replace('~\s+~u', '-', $s);
    if ($t === null) $t = preg_replace('~\s+~', '-', $s);
    $t = function_exists('mb_strtolower') ? mb_strtolower($t, 'UTF-8') : strtolower($t);
    $t = preg_replace('~/+~', '/', $t);
    return trim((string) $t, '/');
}

/** '' (the home page) or up to three segments of letters / digits / hyphens. */
function enw_route_valid($path) {
    if ($path === '') return true;
    if (strlen($path) > 120) return false;
    if (preg_match('~^[\p{L}\p{N}]+(?:-[\p{L}\p{N}]+)*(?:/[\p{L}\p{N}]+(?:-[\p{L}\p{N}]+)*){0,2}$~u', $path) !== 1) return false;
    $segments = explode('/', $path);
    return !in_array($segments[0], enw_route_reserved_segments(), true);
}

/** Route => URL path (non-ASCII letters percent-encoded). */
function enw_route_encode($route) {
    return implode('/', array_map('rawurlencode', explode('/', (string) $route)));
}

function enw_routes_default() {
    return ['en' => [
        ''        => ['page' => 'home',    'redirect' => false, 'auto' => false],
        'product' => ['page' => 'product', 'redirect' => false, 'auto' => false],
        'contact' => ['page' => 'contact', 'redirect' => false, 'auto' => false],
    ]];
}

function enw_routes_raw() {
    if (!is_file(ENW_ROUTES_FILE)) return [];
    $d = json_decode((string) file_get_contents(ENW_ROUTES_FILE), true);
    return is_array($d) ? $d : [];
}

/**
 * The route table: lang => [route => ['page', 'redirect', 'auto']].
 * 'redirect' = answer with a 301 to the page's real address instead of showing it;
 * 'auto'     = such a redirect was created automatically when a route was changed.
 */
function enw_routes_load() {
    if (isset($GLOBALS['__enw_routes_cache'])) {
        return $GLOBALS['__enw_routes_cache'];
    }
    $pages = enw_pages_load();
    $raw = enw_routes_raw();
    $out = ['en' => [], 'fr' => [], 'zh' => [], 'ja' => []];

    if (isset($raw['routes']) && is_array($raw['routes'])) {
        foreach (enw_route_langs() as $l) {
            if (!isset($raw['routes'][$l]) || !is_array($raw['routes'][$l])) continue;
            foreach ($raw['routes'][$l] as $path => $e) {
                $path = enw_route_normalize((string) $path);
                if (!enw_route_valid($path) || !is_array($e)) continue;
                $page = (isset($e['page']) && is_string($e['page'])) ? $e['page'] : '';
                if (!isset($pages[$page]) || $pages[$page]['hidden']) continue;
                if ($path === '' && $page !== 'home') continue;        // "/" is always the home page
                $out[$l][$path] = [
                    'page'     => $page,
                    'redirect' => ($path !== '' && !empty($e['redirect'])),
                    'auto'     => !empty($e['auto']),
                ];
            }
        }
    } else {
        $out['en'] = enw_routes_default()['en'];
    }
    // The home page always lives at "/" in English (and comes first).
    $out['en'] = ['' => ['page' => 'home', 'redirect' => false, 'auto' => false]] + $out['en'];

    $GLOBALS['__enw_routes_cache'] = $out;
    return $out;
}

/**
 * Which page does this URL show? Looks in the language's own routes, then in the
 * English ones (a page without its own French address simply keeps its English one
 * under /fr/). Returns null, or ['page', 'redirect', 'auto', 'lang', 'path'].
 */
function enw_route_resolve($lang, $path) {
    $routes = enw_routes_load();
    $tryLangs = ($lang === 'en') ? ['en'] : [$lang, 'en'];
    foreach ($tryLangs as $l) {
        if (isset($routes[$l][$path])) {
            return $routes[$l][$path] + ['lang' => $l, 'path' => (string) $path];
        }
    }
    return null;
}

/** The address of a page in a language (null if it has none): the language's own, else the English one. */
function enw_page_route($page, $lang) {
    $routes = enw_routes_load();
    $tryLangs = ($lang === 'en') ? ['en'] : [$lang, 'en'];
    foreach ($tryLangs as $l) {
        foreach ($routes[$l] as $path => $e) {
            if ($e['page'] === $page && !$e['redirect']) {
                return (string) $path;
            }
        }
    }
    return null;
}

/** A page id from what the language switcher / old links pass: an id, 'product.php', '', ... */
function enw_page_key_from_param($v) {
    $v = trim((string) $v);
    $pages = enw_pages_load();
    if (isset($pages[$v]) && !$pages[$v]['hidden']) return $v;
    if ($v === '' || $v === 'index.php') return 'home';
    foreach ($pages as $k => $p) {
        if (!$p['hidden'] && ($p['template'] === $v || $p['template'] === $v . '.php')) return $k;
    }
    $hit = enw_route_resolve('en', enw_route_normalize($v));
    return ($hit !== null && !$hit['redirect']) ? $hit['page'] : null;
}

// --- SEO texts of a page ------------------------------------------------------------

/** Where a page's SEO texts live in the language files: home.meta / product.meta / contact.meta as always, pages.<id>.meta for new pages. */
function enw_page_meta_path($key) {
    return in_array($key, ['home', 'product', 'contact'], true) ? $key . '.meta' : 'pages.' . $key . '.meta';
}

/** title / description / keywords in a language; an empty one falls back to English. */
function enw_page_meta_values($key, $lang) {
    $path = enw_page_meta_path($key);
    $own = enw_dig(enw_lang_content($lang), $path);
    $en  = enw_dig(enw_lang_content('en'), $path);
    $own = is_array($own) ? $own : [];
    $en  = is_array($en) ? $en : [];
    $out = [];
    foreach (['title', 'description', 'keywords'] as $k) {
        $v = (isset($own[$k]) && is_string($own[$k])) ? $own[$k] : '';
        if ($v === '') $v = (isset($en[$k]) && is_string($en[$k])) ? $en[$k] : '';
        $out[$k] = $v;
    }
    return $out;
}
