<?php
// /sitemap.xml and /robots.txt, generated from the pages and routes tables
// (router.php includes this file). Draft pages and the 404 page are left out.

$lang = 'en';
require_once __DIR__ . '/config.php';

$base = rtrim(SITE_URL, '/');

if (parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) === '/robots.txt') {
    header('Content-Type: text/plain; charset=utf-8');
    echo "User-agent: *\nAllow: /\nDisallow: /admin/\n\nSitemap: " . $base . "/sitemap.xml\n";
    return;
}

function enw_sitemap_h($s) {
    return htmlspecialchars((string) $s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
}

header('Content-Type: application/xml; charset=utf-8');
echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";

foreach (enw_pages_load() as $key => $p) {
    if ($p['hidden'] || $p['status'] !== 'published') continue;

    // The address of this page in every language that has one.
    $urls = [];
    foreach ($GLOBALS['LANGUAGES'] as $code => $meta) {
        $route = enw_page_route($key, $code);
        if ($route !== null) {
            $urls[$code] = $base . '/' . $meta['prefix'] . enw_route_encode($route);
        }
    }
    foreach ($urls as $code => $loc) {
        echo "  <url>\n    <loc>" . enw_sitemap_h($loc) . "</loc>\n";
        foreach ($urls as $c2 => $alt) {
            echo '    <xhtml:link rel="alternate" hreflang="' . enw_sitemap_h($GLOBALS['LANGUAGES'][$c2]['html_lang']) . '" href="' . enw_sitemap_h($alt) . '"/>' . "\n";
        }
        echo "  </url>\n";
    }
}
echo "</urlset>\n";
