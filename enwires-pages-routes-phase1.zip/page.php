<?php
// The generic page template: shows ANY page created in the admin (Pages + Routes).
// router.php sets ENWIRES_PAGE_KEY; the content is the page's blocks, edited in
// /admin/builder.php?page=<key>. (Home, Product and Contact keep their own templates.)
if (!isset($lang)) { $lang = 'en'; }
require_once __DIR__ . '/includes/config.php';

$pageKey = defined('ENWIRES_PAGE_KEY') ? ENWIRES_PAGE_KEY : '';
$pageInfo = ($pageKey !== '') ? enw_page_get($pageKey) : null;
if ($pageInfo === null) {
    // Opened directly (/page.php) instead of through the router.
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    exit('404 Not Found');
}

// SEO texts: edited per page and language in the block builder ("Page settings").
$meta = enw_page_meta_values($pageKey, CURRENT_LANG);
$pageTitle = $meta['title'] !== '' ? $meta['title'] : $pageInfo['title'];
if ($meta['description'] !== '') { $pageDescription = $meta['description']; }
if ($meta['keywords'] !== '')    { $pageKeywords = $meta['keywords']; }

// Social-share image: the first photo found on the page, if any.
$ogSrc = enw_first_image_src($pageKey);
if ($ogSrc) { $pageImage = 'assets/img/' . $ogSrc; }

require_once __DIR__ . '/includes/header.php';

enw_render_blocks($pageKey);
?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
