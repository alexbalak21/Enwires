<?php
// The language switcher's endpoint: remembers the visitor's choice (cookie), then sends
// them to the SAME page in the chosen language — using that language's own address
// from the route table (Admin -> Routes).
//
//   /set-lang.php?lang=fr&to=<page id>        (old links with ?to=product.php still work)

$target = isset($_GET['lang']) ? (string) $_GET['lang'] : '';
if (!in_array($target, ['en', 'fr', 'zh', 'ja'], true)) {
    $target = 'en';
}
$lang = $target;                                  // config.php reads $lang
require_once __DIR__ . '/includes/config.php';    // languages + the pages/routes helpers

// Never trust "to": it is turned into a known page id, never used as a URL.
$key = enw_page_key_from_param(isset($_GET['to']) ? $_GET['to'] : '');
$route = ($key !== null) ? enw_page_route($key, $target) : null;

$prefix = isset($GLOBALS['LANGUAGES'][$target]) ? $GLOBALS['LANGUAGES'][$target]['prefix'] : '';
$destination = '/' . $prefix . ($route !== null ? enw_route_encode($route) : '');

setcookie('enwires_lang', $target, time() + 60 * 60 * 24 * 365, '/');
header('Location: ' . $destination, true, 302);
exit;
